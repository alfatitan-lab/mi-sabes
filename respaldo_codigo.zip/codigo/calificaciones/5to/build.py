import json, hashlib, os, base64, unicodedata, re, datetime
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

ITER = 150000
D = json.load(open('/tmp/cal5/data.json'))
FE = json.load(open('/tmp/cal5/fechas5.json'))
GE = json.load(open('/tmp/cal5/genero5.json'))
AP = {'V24152M0013':'Xime','V24152M0003':'Alessita','V24152M0014':'Pao','V24152M0010':'Arturito','V24152M0030':'Jaqui','V24152M0023':'Chuchín','V24152M0028':'Fati','V24152M0016':'Xime','V24152M0012':'Estrellita','V24152M0031':'Ari','V24152M0006':'Remy','V24152M0027':'Fanisita'}
US = []
PLAN = [("adm", "Administración", "#E08A00"), ("ch2", "Conciencia Histórica II", "#D6336C"), ("pcc", "Práctica y Colaboración Ciudadana", "#2F9E5B")]
DOW = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
MON = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]

def strip(x):
    return ''.join(c for c in unicodedata.normalize('NFD', x) if unicodedata.category(c) != 'Mn').upper()

def cap(s):
    return ' '.join(w.capitalize() for w in s.split())

def label(f):
    d = datetime.date.fromisoformat(f[:10])
    t = f"{DOW[d.weekday()].capitalize()} {d.day} de {MON[d.month-1]}"
    if '~' in f:
        t += f" ({f.split('~')[1]}ª sesión)"
    return t

def enc(obj, mat, pw):
    salt = os.urandom(16); iv = os.urandom(12)
    k = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=ITER).derive((mat + "|" + pw).encode())
    ct = AESGCM(k).encrypt(iv, json.dumps(obj, ensure_ascii=False).encode(), None)
    b = lambda x: base64.b64encode(x).decode()
    return {"s": b(salt), "i": b(iv), "c": b(ct)}

recs = {}
check = []
for mat in D['L']:
    st = D['st'][mat]
    fe = FE[mat]; first = f"{fe['day']:02d}{fe['month']:02d}{fe['year']}"
    US.append([cap(st['nombres'] + ' ' + st['ap'] + ' ' + st['am']), mat])
    mats = []
    for mid, mname, color in PLAN:
        dd = sorted([d for d in D['days'] if d['m'] == mid], key=lambda d: d['f'])
        rows = []; exp = got = 0
        for d in dd:
            act = 0 if '~' in d['f'] else 2
            s = d['s'][mat]; a = d['a'][mat]
            sv = int(s) if s != '' else 0
            av = int(a) if a != '' else 0
            exp += d['meta'] + act; got += sv + (av if act else 0)
            rows.append({"l": label(d['f']), "m": d['meta'], "s": sv, "sb": s == '', "act": act, "a": av, "ab": a == ''})
        c0 = round(min(10, got / exp * 10), 1)
        target = 6 if c0 < 6 else min(10, c0 + 1)
        b = 0
        while round(min(10, (got + b) / exp * 10), 1) < target - 1e-9 and got + b < exp:
            b += 1
        c = round(min(10, (got + b) / exp * 10), 1)
        mats.append({"id": mid, "n": mname, "col": color, "exp": exp, "got": got, "b": b, "c0": c0, "low": c0 < 6, "c": c, "d": rows})
    ACC = {'Raul':'Raúl','Jose':'José','Angel':'Ángel','Jesus':'Jesús','Fatima':'Fátima','America':'América','Veronica':'Verónica','Estefania':'Estefanía'}
    nombre = AP.get(mat) or cap(st['nombres'].split()[0]); nombre = ACC.get(nombre, nombre)
    obj = {"g": "F" if GE[mat].startswith("F") else "M", "n": nombre, "full": cap(st['nombres'] + ' ' + st['ap'] + ' ' + st['am']), "m": mats}
    lid = hashlib.sha256(("id|" + mat).encode()).hexdigest()[:16]
    recs[lid] = enc(obj, mat, first)
    check.append((mat, first, [x['c'] for x in mats], [x['c0'] for x in mats], [x['b'] for x in mats]))

US.sort(key=lambda x: strip(x[0]))
json.dump({"it": ITER, "r": recs, "u": US}, open('/tmp/cal5/cifrado5.json', 'w'))
json.dump(check, open('/tmp/cal5/check.json', 'w'), ensure_ascii=False)
print(len(recs), "registros")
