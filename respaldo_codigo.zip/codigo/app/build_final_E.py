import re, base64, json
t=open('app_template_E.html').read()
old=open('/mnt/user-data/outputs/index.html').read()
url=re.search(r'const COUNTER_URL = "([^"]+)"',old).group(1)
assert t.count('const COUNTER_URL = "";')==1
t=t.replace('const COUNTER_URL = "";','const COUNTER_URL = "%s";'%url)
t=t.replace('/*DATA*/',open('cifrado.json').read())
def b64(path): return base64.b64encode(open(path,'rb').read()).decode()
SITE="https://alfatitan-lab.github.io/mi-sabes/"
icon192="data:image/png;base64,"+b64('/tmp/w/icon-192-E.png')
icon512="data:image/png;base64,"+b64('/tmp/w/icon-512-E.png')
apple="data:image/png;base64,"+b64('/tmp/w/apple-touch-icon-E.png')
manifest={"name":"Mi SABES La Palma","short_name":"Mi SABES","description":"Horario, calificaciones y cuenta regresiva de SABES La Palma","start_url":SITE,"scope":SITE,"id":SITE,"display":"standalone","orientation":"portrait","background_color":"#F2F6FF","theme_color":"#1D4ED8","lang":"es",
 "icons":[{"src":icon192,"sizes":"192x192","type":"image/png","purpose":"any"},{"src":icon512,"sizes":"512x512","type":"image/png","purpose":"any"},{"src":icon512,"sizes":"512x512","type":"image/png","purpose":"maskable"}]}
mf="data:application/manifest+json;base64,"+base64.b64encode(json.dumps(manifest,ensure_ascii=False).encode()).decode()
head='''<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="light dark">
<meta name="theme-color" content="#1D4ED8">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Mi SABES">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="icon" type="image/png" href="icon-192.png">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<link rel="manifest" href="manifest.webmanifest">
'''
i=t.index('</style>')+len('</style>')
t=head+t[:i]+'''
<style>html{-webkit-text-size-adjust:100%;text-size-adjust:100%;}body{margin:0;}img{max-width:100%;}</style>
</head>
<body>'''+t[i:]+'\n</body>\n</html>\n'
open('/tmp/w/index.html','w').write(t)
print(len(t))
