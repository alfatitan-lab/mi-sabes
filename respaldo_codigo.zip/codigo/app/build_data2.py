import glob, sys, json, secrets, hashlib, os, base64, collections, re
sys.path.insert(0,'.')
from parse import load, A
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ITER = 600000
ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   # sin I, O, 0, 1
SEM_LABEL = {"V24":"5to semestre","V25":"3er semestre","V26":"1er semestre"}

import unicodedata
def nk(x):
    x=unicodedata.normalize('NFD',x); x=''.join(c for c in x if unicodedata.category(c)!='Mn')
    return re.sub(r'\s+',' ',x).strip().upper()
def norm_mat(m): return re.sub(r'\s+','',m).upper()
def norm_pw(p):  return re.sub(r'[\s\-]','',p).upper()
def title(s):    return ' '.join(w.capitalize() for w in s.split())

def val(v):
    if v in (None,''): return None
    if v == '----': return None          # aun sin capturar
    if v == 'NP': return 'NP'
    return float(v)

records=[]
OLD={'V24':'536a777b','V25':'c2cae313','V26':'d9783b74'}      # concentrados con historial completo (1er parcial)
NEW={'V26':'62371a9e','V25':'b1414d8e','V24':'d96780aa'}      # concentrados actuales (solo semestre en curso)
CUR={'V24':5,'V25':3,'V26':1}
def fpath(pref): return [x for x in glob.glob(A+'*.xls') if x.split('/')[-1].startswith(pref)][0]
def bloques(rows):
    h=rows[0]; data=rows[1:]
    mat_row=[r for r in data if r[0]=='MATERIA'][0]
    stud=[r for r in data if len(r)>2 and r[2]]
    codes=h[6:]
    uacs=collections.OrderedDict()
    for i,c in enumerate(codes,6):
        base=c[:-2]
        e=uacs.setdefault(base,{"s":int(base[4]),"n":mat_row[i].strip(),"idx":{}})
        e["idx"][int(c[-1])]=i
    res={}
    for r in stud:
        sems=collections.OrderedDict()
        for base,e in uacs.items():
            ps=[val(r[e["idx"][k]]) if e["idx"][k]<len(r) else None for k in (1,2,3)]
            raw=[(r[e["idx"][k]] if e["idx"][k]<len(r) else None) for k in (1,2,3)]
            if all(x in (None,'') for x in raw): continue
            sems.setdefault(e["s"],[]).append({"n":re.sub(r'\s+',' ',e["n"]),"p":ps})
        res[norm_mat(r[2])]=(r,sems)
    return res
for pref,oldp in OLD.items():
    cur=CUR[pref]
    O=bloques(load(fpath(oldp))); N=bloques(load(fpath(NEW[pref])))
    assert set(N)<=set(O), ("alumno nuevo sin historial",set(N)-set(O))
    cambios=0
    for mat,(r,sems_new) in N.items():
        sems=collections.OrderedDict((s,u) for s,u in O[mat][1].items() if s<cur)
        sems[cur]=sems_new.get(cur,[])
        if sems_new.get(cur)!=O[mat][1].get(cur): cambios+=1
        records.append({
            "nk":nk(r[3]+' '+r[4]+' '+r[5]),
            "mat":mat,
            "grupo":SEM_LABEL[mat[:3]],
            "nombre":title(r[5])+" "+title(r[3]),
            "sem":[{"s":s,"u":u} for s,u in sorted(sems.items())]
        })
    print(pref,"alumnos",len(N),"| bajas fuera",len(set(O)-set(N)),"| con cambios en semestre actual",cambios)

# contraseñas: se reutilizan las ya entregadas
from openpyxl import load_workbook
_ws=load_workbook('/mnt/user-data/outputs/Contrasenas_calificaciones.xlsx').active
PW={row[1]:row[3].replace('-','') for row in _ws.iter_rows(min_row=2,values_only=True)}
assert {r["mat"] for r in records}<=set(PW), "matricula sin contraseña"
for rec in records: rec["pw"]=PW[rec["mat"]]

# servicio social
from openpyxl import load_workbook as _lw
_wb=_lw('/mnt/user-data/attachments/dc2c133f-a4a8-59a8-b21c-0c8409a40fa7/ab2ee2ed-Social_Definitivo.xlsx',data_only=True)
_a=_wb[_wb.sheetnames[0]]
SSL={nk(r[1]):(int(r[2]),int(r[5])) for r in _a.iter_rows(min_row=4,max_col=6,values_only=True) if r[1]}
_n5=0
for rec in records:
    if rec["grupo"]=="5to semestre":
        if rec["nk"] in SSL:
            h,f=SSL[rec["nk"]]; rec["ss"]={"e":"pen","h":h,"f":f,"m":64}
        else:
            rec["ss"]={"e":"lib"}
    else:
        rec["ss"]={"e":"off","t":144}
assert sum(1 for r in records if r["ss"]["e"]=="pen")==len(SSL)==22

# top 10 por semestre y general, dentro de su semestre (grupo)
ENCURSO={"1er semestre":1,"3er semestre":3,"5to semestre":5}
def isnum(x): return isinstance(x,float)
def uprom(u): return sum(u["p"])/3 if all(isnum(p) for p in u["p"]) else None
def sem_avg(b):
    pr=[uprom(u) for u in b["u"]]
    return sum(pr)/len(pr) if pr and all(p is not None for p in pr) else None   # solo semestres completos
for rec in records:
    cur=ENCURSO[rec["grupo"]]
    rec["_sem"]={b["s"]:sem_avg(b) for b in rec["sem"] if b["s"]<cur}
    ok = all(s in rec["_sem"] and rec["_sem"][s] is not None for s in range(1,cur))
    if ok and cur>1:
        todas=[uprom(u) for b in rec["sem"] if b["s"]<cur for u in b["u"]]
        rec["_gen"]=sum(todas)/len(todas)
    else: rec["_gen"]=None
def lugares(vals):
    """vals: dict mat->promedio. Lugar por promedio a 3 decimales; empates comparten lugar."""
    r={m:round(v,3) for m,v in vals.items() if v is not None}
    out={}
    for m,v in r.items():
        place=1+sum(1 for w in r.values() if w>v)
        tied=sum(1 for w in r.values() if w==v)>1
        x=sum(1 for w in r.values() if round(w,2)==round(v,2))>1
        out[m]=(place,tied,x)
    return out
for g in ENCURSO:
    grp=[r for r in records if r["grupo"]==g]
    for r in grp: r["top"]={}
    for s in range(1,ENCURSO[g]):
        L=lugares({r["mat"]:r["_sem"].get(s) for r in grp})
        for r in grp:
            pl=L.get(r["mat"])
            if pl and pl[0]<=10: r["top"][str(s)]={"p":pl[0],"e":pl[1],"x":pl[2]}
    L=lugares({r["mat"]:r["_gen"] for r in grp})
    for r in grp:
        pl=L.get(r["mat"])
        if pl and pl[0]<=10: r["top"]["g"]={"p":pl[0],"e":pl[1],"x":pl[2]}


# ===== top 10 del parcial en curso (lo ven todos los alumnos del grupo, dentro de su registro cifrado) =====
PARCIAL_IDX=1                       # 0=P1, 1=P2, 2=P3
PARCIAL_TXT="Segundo parcial"
FECHA_DEF="viernes 6 de noviembre, a las 12 de la noche"
VERSION_T2="p2-1110"
MIN=("de","del","la","las","los","y","en","e","a","al","para","con","o","u")
def bonito(n):
    n=re.sub(r'\s+',' ',n).strip().lower()
    out=[]
    for i,w in enumerate(n.split(' ')):
        if re.fullmatch(r'(i|ii|iii|iv|v|vi)[.:,]?',w): out.append(w.upper())
        elif w in MIN and i>0: out.append(w)
        else: out.append(w[:1].upper()+w[1:])
    return ' '.join(out)
def primeros(nombre): return nombre
CAPS={}
for g,cur in ENCURSO.items():
    grp=[r for r in records if r["grupo"]==g]
    mats=collections.OrderedDict()
    for r in grp:
        for u in [b for b in r["sem"] if b["s"]==cur][0]["u"]:
            mats.setdefault(u["n"],False)
            if isnum(u["p"][PARCIAL_IDX]): mats[u["n"]]=True
    cap=[n for n,v in mats.items() if v]; CAPS[g]=list(cap); falta=[re.sub(r'^Recursos Socioemocionales: ','',bonito(n)) for n,v in mats.items() if not v]
    prom={}
    for r in grp:
        v=[]
        for u in [b for b in r["sem"] if b["s"]==cur][0]["u"]:
            if u["n"] in cap and isnum(u["p"][PARCIAL_IDX]): v.append(u["p"][PARCIAL_IDX])
        prom[r["mat"]]=sum(v)/len(v) if v else None
    # lugares consecutivos: los empatados comparten lugar y el siguiente es el lugar que sigue (1,1,1,2,3...)
    vals=sorted({round(v,3) for v in prom.values() if v is not None}, reverse=True)
    L={m:(1+vals.index(round(v,3)),) for m,v in prom.items() if v is not None}
    lista=sorted([(L[m][0],m) for m in L if L[m][0]<=10], key=lambda x:(x[0],x[1]))
    nom={r["mat"]:r["nombre"] for r in grp}
    fila=[]
    for pl,m in lista:
        v3=round(prom[m],3)
        x=any(round(w,2)==round(v3,2) and round(w,3)!=v3 for k,w in prom.items() if w is not None and k!=m)
        from decimal import Decimal, ROUND_HALF_UP
        d=Decimal(repr(v3)).quantize(Decimal("0.001" if x else "0.01"),rounding=ROUND_HALF_UP)
        fila.append([pl,nom[m],str(d)])
    pos={m:pl for pl,m in lista}
    for r in grp:
        r["t2"]={"v":VERSION_T2,"t":PARCIAL_TXT,"g":g,"l":fila,"f":falta,"c":len(cap),"n":len(mats),"d":FECHA_DEF,"yo":pos.get(r["mat"],0)}
    print("TOP2",g,"capturadas",len(cap),"de",len(mats),"| faltan:",falta)
    for f in fila: print("   ",f)


# ===== cuenta de ejemplo para videos (datos inventados; fuera de rankings y contadores) =====
import random
_rng=random.Random(2026)
_GR=[9.0,9.5,10.0,9.5,10.0,9.7,9.3,10.0,9.0,9.8]
_P2=[10.0,10.0,9.5,10.0,9.5,10.0,9.5,10.0,10.0,10.0]
_base=[r for r in records if r["grupo"]=="5to semestre"][0]
_sem=[]; _k=0
for b in _base["sem"]:
    us=[]
    for u in b["u"]:
        if b["s"]<5: p=[_rng.choice(_GR) for _ in range(3)]
        else:
            p=[_rng.choice(_GR),None,None]
            if u["n"] in CAPS["5to semestre"]: p[1]=_P2[_k%len(_P2)]; _k+=1
        us.append({"n":u["n"],"p":p})
    _sem.append({"s":b["s"],"u":us})
_cap5=CAPS["5to semestre"]
_f5=[re.sub(r'^Recursos Socioemocionales: ','',bonito(n)) for n in [u["n"] for u in _base["sem"][-1]["u"]] if n not in _cap5]
_top=[(1,"Camila Ejemplo","9.95"),(2,"Sofía Ejemplo","9.85"),(3,"Diego Ejemplo","9.78"),(4,"Mateo Ejemplo","9.70"),(5,"Valentina Ejemplo","9.62"),(6,"Emiliano Ejemplo","9.55"),(7,"Renata Ejemplo","9.40"),(8,"Leonardo Ejemplo","9.31"),(9,"Ximena Ejemplo","9.20"),(10,"Santiago Ejemplo","9.05")]
_demo={"nk":"SOFIA EJEMPLO","mat":"DEMO2026","pw":"DEMO2026","grupo":"5to semestre","nombre":"Sofía Ejemplo","sem":_sem,
 "top":{"1":{"p":6,"e":False,"x":False},"3":{"p":4,"e":False,"x":False},"g":{"p":3,"e":False,"x":False}},
 "ss":{"e":"pen","h":40,"f":24,"m":64},
 "t2":{"v":VERSION_T2,"t":PARCIAL_TXT,"g":"5to semestre","l":[[a,b,c] for a,b,c in _top],"f":_f5,"c":len(_cap5),"n":len(_cap5)+len(_f5),"d":FECHA_DEF,"yo":2}}
records.append(_demo)
print("DEMO: matricula DEMO2026 | clave DEMO2026 | faltan",_f5)

# cifrado
def derive(mat,pw,salt):
    return hashlib.pbkdf2_hmac('sha256',(mat+'|'+pw).encode(),salt,ITER,32)
out=[]
for rec in records:
    salt=secrets.token_bytes(16); iv=secrets.token_bytes(12)
    key=derive(rec["mat"],norm_pw(rec["pw"]),salt)
    plain=json.dumps({"n":rec["nombre"],"g":rec["grupo"],"sem":rec["sem"],"top":rec.get("top",{}),"ss":rec["ss"],"t2":rec.get("t2")},ensure_ascii=False,separators=(',',':')).encode()
    ct=AESGCM(key).encrypt(iv,plain,None)
    rid=hashlib.sha256(("id|"+rec["mat"]).encode()).hexdigest()[:16]
    out.append({"i":rid,"s":base64.b64encode(salt).decode(),"v":base64.b64encode(iv).decode(),"c":base64.b64encode(ct).decode()})
import random; random.shuffle(out)
json.dump({"it":ITER,"r":out},open("cifrado.json","w"),separators=(',',':'))
for g in ENCURSO:
    grp=[r for r in records if r["grupo"]==g]
    print(g,"general:",sorted((r["top"]["g"]["p"],r["top"]["g"]["e"]) for r in grp if "g" in r["top"]))
    for s in range(1,ENCURSO[g]):
        print("  sem",s,sorted((r["top"][str(s)]["p"],r["top"][str(s)]["e"]) for r in grp if str(s) in r["top"]))

# resumen de calidad (semestre en curso segun el grupo)
bad=collections.Counter()
for rec in records:
    cur=max(s["s"] for s in rec["sem"])
    for s in rec["sem"]:
        if s["s"]==cur: continue
        for u in s["u"]:
            if any(not isinstance(p,float) for p in u["p"]): bad[rec["mat"]]+=1
print("registros",len(records),"| cifrado.json",os.path.getsize("cifrado.json"),"bytes")
print("alumnos con materias de semestres anteriores incompletas (NP o sin capturar):",len(bad),"| total materias:",sum(bad.values()))
print(collections.Counter(r["grupo"] for r in records))
