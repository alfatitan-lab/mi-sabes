function crearQuien(){
  var ss=SpreadsheetApp.getActiveSpreadsheet();
  var pa=ss.getSheetByName('Por alumno');
  var n=pa.getLastRow();
  var sh=ss.getSheetByName('Quién ingresó')||ss.insertSheet('Quién ingresó');
  sh.clear();
  var out=[['Nombre','Grupo','Ingresos','Sesiones nuevas','Último ingreso']];
  for(var r=2;r<=n;r++){
    var id="'Por alumno'!F"+r;
    out.push(["='Por alumno'!A"+r,"='Por alumno'!B"+r,
      '=COUNTIF(Ingresos!C:C,'+id+')',
      '=COUNTIFS(Ingresos!C:C,'+id+',Ingresos!D:D,"no")',
      '=IFERROR(LOOKUP(2,1/(Ingresos!C$2:C='+id+'),Ingresos!A$2:A),"")']);
  }
  sh.getRange(1,1,out.length,5).setValues(out);
  sh.getRange(1,1,1,5).setFontWeight('bold');
  sh.setFrozenRows(1);
  sh.setColumnWidth(1,240);sh.setColumnWidth(5,160);
  sh.getRange(1,1,out.length,5).createFilter();
  return out.length;
}
