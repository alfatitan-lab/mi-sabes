import re, sys, glob, json
import xml.etree.ElementTree as ET
A='/mnt/user-data/attachments/dc2c133f-a4a8-59a8-b21c-0c8409a40fa7/'
ns={'ss':'urn:schemas-microsoft-com:office:spreadsheet'}
def load(f):
    raw=open(f,encoding='utf-8').read()
    raw=raw.replace('<xml version>','<?xml version="1.0"?>',1)
    raw=raw.replace('xmlns:x="urn:schemas-    microsoft-com:office:excel"','xmlns:x="urn:schemas-microsoft-com:office:excel"')
    raw=re.sub(r'<Style\s+ss:ID','<Style ss:ID',raw)
    root=ET.fromstring(raw)
    rows=[]
    for r in root.iter('{%s}Row'%ns['ss']):
        row=[]
        for c in r.findall('ss:Cell',ns):
            idx=c.get('{%s}Index'%ns['ss'])
            if idx:
                while len(row)<int(idx)-1: row.append(None)
            d=c.find('ss:Data',ns)
            row.append(d.text if d is not None else None)
        rows.append(row)
    return rows
if __name__=='__main__':
    for f in sorted(glob.glob(A+'*.xls')):
        rows=load(f)
        print(f.split('/')[-1][:10], len(rows), 'rows', len(rows[0]),'cols')
        print(rows[0][:6], '...', rows[0][-4:])
        print([ (c) for c in rows[0][6:] ][:60])
