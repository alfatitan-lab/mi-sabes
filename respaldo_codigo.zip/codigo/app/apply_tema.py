import re, sys
S_OLD_LIGHT="--s0:#F8D4E4; --s1:#FFE0B8; --s2:#E2D2F2; --s3:#FAEDAE; --s4:#C9EDE2; --s5:#D3E4FA; --s6:#F6D0C4; --s7:#DCEBC2; --s8:#F3D7F0; --s9:#CFE9F0; --s10:#EBDDC6; --s11:#E6E0A8;"
S_OLD_DARK="--s0:#4C2540; --s1:#503A18; --s2:#3C2A58; --s3:#4A4416; --s4:#17493D; --s5:#203D60; --s6:#542C22; --s7:#34461B; --s8:#4B2A49; --s9:#1B4455; --s10:#493D28; --s11:#444018;"
def sets(light,dark): return light,dark
THEMES={
"E":dict(
 fonts="Space+Grotesk:wght@500;700&family=DM+Sans:wght@400;600;700",
 disp='"Space Grotesk","Arial Narrow",system-ui,sans-serif', body='"DM Sans",system-ui,-apple-system,"Segoe UI",sans-serif',
 light="""--bg:#F2F6FF; --card:#FFFFFF; --fg:#0B1B3A; --muted:#52638A; --line:#D5DEF2;
    --blue:#1D4ED8; --blue-soft:#DCE6FF; --mari:#E8420C; --orange:#C2410C; --red:#C62828; --ok:#17803D; --ok-soft:#DCF2E3;
    --k-sin:#C2185B; --k-sin-soft:#FCE0EA; --k-eval:#1D4ED8; --k-tram:#B85C00; --k-evt:#0F7D6B; --k-aviso:#5B3FA8;
    --past:#C5D0E8; --on-fill:#FFFFFF;
    %s
    --gold-a:#FFF3CF; --gold-b:#FFFBEC; --gold-line:#E2B94B; --gold-ink:#8A5A00;"""%S_OLD_LIGHT,
 dark="""--bg:#070D1F; --card:#0F1A38; --fg:#EAF0FF; --muted:#8FA3D1; --line:#1D2C57;
    --blue:#6EA0FF; --blue-soft:#17275A; --mari:#C6F432; --orange:#FFB347; --red:#FF7A7A; --ok:#5BD58C; --ok-soft:#123326;
    --k-sin:#F0709F; --k-sin-soft:#3A2234; --k-eval:#6EA0FF; --k-tram:#FFA040; --k-evt:#4FD1B5; --k-aviso:#B9A6FF;
    --past:#2A3A6A; --on-fill:#070D1F; color-scheme:dark;
    %s
    --gold-a:#3D3110; --gold-b:#2A2210; --gold-line:#B8923A; --gold-ink:#F2C95B;"""%S_OLD_DARK,
 stripe="repeating-linear-gradient(90deg,var(--blue) 0 22px,var(--mari) 22px 44px,var(--fg) 44px 66px)", stripeh="5px",
 confeti='["#C6F432", "#E8420C", "#6EA0FF", "#1D4ED8", "#FFD23F", "#FFFFFF", "#FF7A45"]',
 extra="", theme="#1D4ED8", bgc="#F2F6FF"),
"F":dict(
 fonts="Playfair+Display:wght@700;800&family=Public+Sans:wght@400;600;700",
 disp='"Playfair Display",Georgia,"Times New Roman",serif', body='"Public Sans",system-ui,-apple-system,"Segoe UI",sans-serif',
 light="""--bg:#FAFAF7; --card:#FFFFFF; --fg:#111111; --muted:#666660; --line:#E2E2DC;
    --blue:#111111; --blue-soft:#EEEEE8; --mari:#C8102E; --orange:#B45309; --red:#C8102E; --ok:#17803D; --ok-soft:#DCF2E3;
    --k-sin:#C8102E; --k-sin-soft:#FBE3E6; --k-eval:#111111; --k-tram:#B45309; --k-evt:#0F7D6B; --k-aviso:#5B3FA8;
    --past:#D6D6CE; --on-fill:#FFFFFF;
    --s0:#F1D9DC; --s1:#F3E3CB; --s2:#E4DDEE; --s3:#F1EBC6; --s4:#D7EADF; --s5:#D9E4F1; --s6:#F0D8CF; --s7:#E1EACD; --s8:#EDDAEA; --s9:#D5E8EC; --s10:#E8DFD0; --s11:#E8E5C4;
    --gold-a:#FCE9EA; --gold-b:#FFF6F6; --gold-line:#C8102E; --gold-ink:#8F0B20;""",
 dark="""--bg:#0E0E0E; --card:#181818; --fg:#F2F2EE; --muted:#9A9A94; --line:#2C2C2C;
    --blue:#F2F2EE; --blue-soft:#262626; --mari:#FF5A5F; --orange:#FFB347; --red:#FF7A7A; --ok:#5BD58C; --ok-soft:#173A29;
    --k-sin:#FF6F78; --k-sin-soft:#3A2224; --k-eval:#F2F2EE; --k-tram:#FFA040; --k-evt:#4FD1B5; --k-aviso:#B9A6FF;
    --past:#3A3A3A; --on-fill:#0E0E0E; color-scheme:dark;
    --s0:#3A2A2D; --s1:#3A3125; --s2:#31293D; --s3:#38351F; --s4:#22372E; --s5:#243242; --s6:#3D2B25; --s7:#2F3A22; --s8:#392A38; --s9:#20373D; --s10:#373024; --s11:#37361F;
    --gold-a:#3A1A1D; --gold-b:#2A1416; --gold-line:#B03A40; --gold-ink:#FF9A9E;""",
 stripe="var(--fg)", stripeh="3px",
 confeti='["#C8102E", "#111111", "#F2F2EE", "#FF5A5F", "#9A9A94", "#E5C07B", "#FFFFFF"]',
 extra="  .big,h1,h2,h3,.unit,.stat dd,.ev .when,.ch b,.mats .hr,.semhead .avg,.grad .gn b,.podio .pl,.dtabs button b,.wh b{font-variant-numeric:lining-nums tabular-nums;}\n  .papel{color:var(--fg);}\n",
 theme="#111111", bgc="#FAFAF7"),
}
def banderines():
    cl=["f1","f2","f3"]; p=['<line x1="0" y1="4" x2="400" y2="4" stroke="currentColor" stroke-width="1.5" opacity=".6"/>']
    x=2;i=0
    while x+28<=400:
        p.append('<path class="%s" d="M%d 4H%d L%d 44Z"/>'%(cl[i%3],x,x+28,x+14)); x+=30;i+=1
    return '<svg viewBox="0 0 400 48" xmlns="http://www.w3.org/2000/svg" focusable="false">'+"".join(p)+'</svg>'
RULE='<svg viewBox="0 0 400 18" xmlns="http://www.w3.org/2000/svg" focusable="false"><line x1="0" y1="3" x2="400" y2="3" stroke="currentColor" stroke-width="3"/><line x1="0" y1="8" x2="400" y2="8" stroke="currentColor" stroke-width="1"/><path d="M200 12l5 3-5 3-5-3z" fill="var(--mari)"/></svg>'
def aplicar(t,k):
    c=THEMES[k]
    t=re.sub(r'family=Archivo:wght@600;800&family=Public\+Sans:wght@400;600;700','family='+c["fonts"],t,count=1)
    a=t.index('  :root{'); b=t.index('  [hidden]{display:none!important;}')
    css=f"""  :root{{
    {c['light']}
    --font-display:{c['disp']};
    --font-body:{c['body']};
  }}
  @media (prefers-color-scheme: dark){{
    :root:not([data-theme="light"]){{
    {c['dark']}
    }}
  }}
  :root[data-theme="dark"]{{
    {c['dark']}
  }}
"""
    t=t[:a]+css+t[b:]
    # banderitas
    i=t.index('<div class="papel"'); j=t.index('</div>',i)
    svg = banderines() if k=="E" else RULE
    t=t[:i]+'<div class="papel" aria-hidden="true">'+svg+t[j:]
    if k=="E":
        extra="  .papel .f1{fill:var(--blue);} .papel .f2{fill:var(--mari);} .papel .f3{fill:var(--fg);}\n  .papel{margin:-6px 0 10px;}\n"
    else: extra=c['extra']
    t=t.replace('  [hidden]{display:none!important;}',extra+'  [hidden]{display:none!important;}',1)
    # franja de graduacion
    t,n=re.subn(r'(\.grad::before\{content:"";position:absolute;left:0;right:0;top:0;)height:5px;background:repeating-linear-gradient\([^;]+;\}',
        lambda m:m.group(1)+'height:%s;background:%s;}'%(c['stripeh'],c['stripe']),t); assert n==1
    # confeti
    t,n=re.subn(r'const cols = \[[^\]]+\];','const cols = %s;'%c['confeti'],t); assert n==1
    return t
if __name__=="__main__":
    k=sys.argv[1]
    t=open('app_template.html').read()
    open('app_template_%s.html'%k,'w').write(aplicar(t,k))
