
// ---------- Sellos del parcial (captura del maestro y vista del alumno) ----------
var CLAVE_DOCENTE = 'PON_AQUI_LA_CLAVE';
var MATERIAS_ = {hum1:'Humanidades I', lyc1:'Lengua y Comunicación I', cs1:'Ciencias Sociales I', hum3:'Humanidades III', lyc3:'Lengua y Comunicación III', adm:'Administración', ch2:'Conciencia Histórica II', pcc:'Práctica y Colaboración Ciudadana'};

function doPost(e) {
  var d = {};
  try { d = JSON.parse(e.postData.contents); } catch (err) {}
  if (d && d.act === 'sellos') return guardarSellos_(d);
  return doPostIngresos_(e);
}

function doGet(e) {
  var p = (e && e.parameter) || {};
  if (p.q === 'sellos') return json_(vistaAlumno_(String(p.id || '')));
  if (p.q === 'sellos_todo') return json_(String(p.k || '') === CLAVE_DOCENTE ? { ok: true, docs: leerDocs_() } : { ok: false });
  return doGetContenido_(e);
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function hojaSellos_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Sellos');
  if (!sh) {
    sh = ss.insertSheet('Sellos');
    sh.getRange(1, 1, 1, 3).setValues([['Documento', 'Datos (no editar)', 'Actualizado']]).setFontWeight('bold');
    sh.setFrozenRows(1);
    sh.getRange('E1').setValue('Aquí se guardan los sellos que captura el maestro. Cada fila es una materia. No la edites a mano: se llena desde la pantalla de captura.');
  }
  return sh;
}

function leerDocs_() {
  var sh = hojaSellos_(), n = sh.getLastRow() - 1, out = {};
  if (n < 1) return out;
  sh.getRange(2, 1, n, 2).getValues().forEach(function (r) {
    if (!r[0]) return;
    try { out[String(r[0])] = JSON.parse(r[1]); } catch (err) {}
  });
  return out;
}

function guardarSellos_(d) {
  if (String(d.k || '') !== CLAVE_DOCENTE || !d.doc || !d.data) return json_({ ok: false });
  var lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    var sh = hojaSellos_(), n = sh.getLastRow() - 1, fila = 0;
    if (n > 0) {
      var ids = sh.getRange(2, 1, n, 1).getValues();
      for (var i = 0; i < ids.length; i++) if (String(ids[i][0]) === String(d.doc)) { fila = i + 2; break; }
    }
    if (!fila) fila = sh.getLastRow() + 1;
    var txt = JSON.stringify(d.data);
    if (txt.length > 49000) return json_({ ok: false, error: 'muy grande' });
    sh.getRange(fila, 1, 1, 3).setValues([[String(d.doc), txt, new Date()]]);
  } finally {
    lock.releaseLock();
  }
  return json_({ ok: true });
}

function alumnos_() {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Por alumno');
  var v = sh.getRange(2, 1, sh.getLastRow() - 1, 6).getValues();
  return v.map(function (r) { return { n: String(r[0]), g: String(r[1]), m: String(r[2]), id: String(r[5]) }; });
}

function calif_(doc, m) {
  var exp = 0, got = 0, dias = [];
  var days = (doc && doc.days) || {};
  Object.keys(days).sort().forEach(function (k) {
    var d = days[k];
    if (!d || d.meta == null) return;
    var ses = k.indexOf('~') >= 0 ? Number(k.split('~')[1]) : 1;
    var act = ses > 1 ? 0 : 2;
    var s = d.s && d.s[m] != null ? Number(d.s[m]) : null;
    var a = d.a && d.a[m] != null ? Number(d.a[m]) : null;
    exp += Number(d.meta) + act;
    got += (s || 0) + (a || 0);
    dias.push({ f: k, meta: Number(d.meta), act: act, s: s, a: a });
  });
  var c = exp ? Math.round(Math.min(10, got / exp * 10) * 10) / 10 : null;
  return { exp: exp, got: got, c: c, dias: dias };
}

function vistaAlumno_(id) {
  var todos = alumnos_(), yo = null;
  todos.forEach(function (a) { if (a.id === id) yo = a; });
  if (!yo) return { ok: false };
  var sem = yo.g.charAt(0);
  var docs = leerDocs_(), prefijo = 's' + sem + '-';
  var mats = Object.keys(docs).filter(function (k) { return k.indexOf(prefijo) === 0; });
  var grupo = todos.filter(function (a) { return a.g === yo.g; });
  var puntajes = grupo.map(function (a) {
    var cs = [];
    mats.forEach(function (k) { var c = calif_(docs[k], a.m).c; if (c != null) cs.push(c); });
    var prom = cs.length ? Math.round(cs.reduce(function (x, y) { return x + y; }, 0) / cs.length * 10) / 10 : null;
    return { n: a.n, m: a.m, c: prom };
  }).filter(function (p) { return p.c != null; });
  puntajes.sort(function (x, y) { return y.c - x.c || (x.n < y.n ? -1 : 1); });
  var miP = null, lugar = null;
  puntajes.forEach(function (p) { if (p.m === yo.m) miP = p.c; });
  if (miP != null) lugar = 1 + puntajes.filter(function (p) { return p.c > miP; }).length;
  var ultimo = '';
  var sh = hojaSellos_(), nf = sh.getLastRow() - 1;
  if (nf > 0) sh.getRange(2, 3, nf, 1).getValues().forEach(function (r) { if (r[0] && String(r[0]) > ultimo) ultimo = String(r[0]); });
  return {
    ok: true,
    nombre: yo.n,
    grupo: yo.g,
    promedio: miP,
    lugar: lugar,
    de: puntajes.length,
    top: puntajes.slice(0, 10).map(function (p) { return { n: p.n, c: p.c, yo: p.m === yo.m }; }),
    materias: mats.map(function (k) {
      var c = calif_(docs[k], yo.m);
      return { id: k.slice(prefijo.length), nombre: MATERIAS_[k.slice(prefijo.length)] || k, exp: c.exp, got: c.got, c: c.c, dias: c.dias };
    }),
    at: (docs[mats[0]] && docs[mats[0]].at) || ''
  };
}
